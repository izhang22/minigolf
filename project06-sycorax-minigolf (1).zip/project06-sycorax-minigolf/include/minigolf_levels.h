#include "minigolf_utils.h"

minigolf_course_t level1(scene_t *scene);

minigolf_course_t level2(scene_t *scene);

minigolf_course_t level3(scene_t *scene);

minigolf_course_t level4(scene_t *scene);

minigolf_course_t level5(scene_t *scene);

minigolf_course_t get_level(scene_t *scene, int level);
